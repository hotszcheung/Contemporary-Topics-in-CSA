/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AJCS;

/**
 *
 * @author jackh
 */
public class AdvancedMem {

        private String Member[];

        public Member createMem() {
            return null;
        }

        public Member searchMem(String id) {
            //retrun Member.getId();
            return null;
        }

        public Member updateAddress(String id) {
            return null;
        }

        public Member extendGoodTill(String id) {
            return null;
        }
        
        public boolean stillGood(String id){
             return true;
        }
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
