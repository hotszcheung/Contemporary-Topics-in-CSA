/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2;

//import java.awt.Frame;
//import java.awt.Label;
//import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;
import java.util.Calendar;
import javax.swing.*;
/*
 *
 * @author a1
 */
public class DisplayGUIAwtImp implements DisplayUI {
    private Frame frame;
    private Label label;

    
    
    public DisplayGUIAwtImp(){
        frame = new Frame();
        label = new Label();
        
        frame.add(label,BorderLayout.CENTER);
        frame.setSize(50,50);
        frame.show();
      

        
    }
    public void displayTime(String time){
        label.setText(time);
        label.repaint();
    }
}
