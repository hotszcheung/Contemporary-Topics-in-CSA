/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab2;

import java.awt.BorderLayout;
import java.awt.Label;


import javax.swing.*;
/**
 *
 * @author a1
 */
public class DisplayGUISwingImp implements DisplayUI{
    private JFrame frame;
    private JLabel label;
    
    public DisplayGUISwingImp(){       
        
        frame = new JFrame();
        label = new JLabel();
        frame.add(label,BorderLayout.CENTER);
        frame.setSize(50,50);
        frame.show();
        
    }
    public void displayTime(String time){
        label.setText(time);
        label.repaint();
      
    }
}
