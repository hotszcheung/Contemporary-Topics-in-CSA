/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5Part1;

import java.util.Stack;

/**
 *
 * @author a1
 */
public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        int id=1;
        Command c1 = new Command1(id);
        Command c2 = new Command2(2);
        
        Stack cmdStack = new Stack();
        
        cmdStack.push(c1);   cmdStack.push(c2);
        c1.execute();
     
        c2.execute();
        
        
        Command ud = (Command)cmdStack.pop();
        ud.undo();
        
        ud =(Command)cmdStack.pop();
        ud.undo();
        
    }

}
