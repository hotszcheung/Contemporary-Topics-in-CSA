/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5Part1;

/**
 *
 * @author a1
 */
public class Command1 implements Command {

    private int id;

    public Command1(int id) {
        this.id = id;
    }

    public void execute() {
        System.out.println(id + " Command1: +execute()");

    }

    public void undo() {
        System.out.println(id + " Command1:undo()");
    }
    
}
