/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab5Part3;
import java.util.*;
import java.io.*;
/**
 *
 * @author a1
 */
public class CreateCircleCmd {
    public CreateCircleCmd (){
    
    }
    public void execute(){
        System.out.print("Enter radius: ");
        line = br.readLine();
        int radius = Integer.parseInt(line);
						shape = new Circle(radius);
						shapes.add(shape);
						history.push(new Action(4, shape, -1));
    }
}