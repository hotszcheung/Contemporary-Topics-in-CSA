package lab5Part3;

public interface Shape {
	public void draw();
}