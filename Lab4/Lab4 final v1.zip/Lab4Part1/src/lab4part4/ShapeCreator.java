/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab4part4;


/**
 *
 * @author a1
 */
public abstract class ShapeCreator {
    public abstract Shape CreateShape()throws Exception;
     
    /*public void anOperation()throws Exception{
        Shape p = CreateShape();
        System.out.println("Shape Created:Width " + p.getWidth()+"and Height:"+p.getHeight());
    }*/
}
