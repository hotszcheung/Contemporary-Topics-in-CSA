/**
 * <p>
 * Title: </p>
 * <p>
 * Description: </p>
 * <p>
 * Copyright: Copyright (c) 2004</p>
 * <p>
 * Company: </p>
 *
 * @author Clarence Lau
 * @version 1.0
 */
package lab4part3;

import java.util.*;
import java.io.*;

public class Main {

    public static void main(String[] args) {
        Vector _shapes = new Vector();
        boolean cont = true;
        InputStreamReader is = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(is);

        try {
            while (cont) {
                System.out.println("Enter command: 0 = exit, 1 = draw all shapes, 2 = create circle, 3 = create rectangle");
                String line = br.readLine();
                int command = Integer.parseInt(line);
                ShapeCreator c1;
                if (command == 0) {
                    cont = false;
                } else if (command == 1) {
                    for (int i = 0; i < _shapes.size(); i++) {
                        ((Shape) _shapes.elementAt(i)).draw();
                    }
                } else if (command == 2) {
                    c1 = new CircleCreator();
                    _shapes.add(c1.CreateShape());
                } else if (command == 3) {
                    c1 = new RectangleCreator();
                    _shapes.add(c1.CreateShape());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
