/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4part1a;

/**
 *
 * @author a1
 */
public class TestFactoryMethod {

    public static void main(String[] args) {
        String[] creators = {"lab4part1a.ConcreteCreatorA", "lab4part1a.ConcreteCreatorB"};
           
        try {
            int choice = Integer.parseInt(args[0]);
            Creator c
                    = (Creator) Class.forName(creators[choice]).newInstance();
            c.anOperation();
        } catch (Exception e) {
            System.out.println("Problem Encoutered");
        }
    }

}
