/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4part1b;

/**
 *
 * @author a1
 */
public class TestAbstractFactory {

    public static void main(String[] args) {
        String[] factories = {"lab4part1b.ConcreteFactory1", "lab4part1b.ConcreteFactory2"};
        try {
            Client c = new Client();
                int choice = Integer.parseInt(args[0]);

            AbstractFactory af
                    = (AbstractFactory) Class.forName(factories[choice]).newInstance();

            System.out.println("Product A Created : "
                    + c.createA(af).getName());
            System.out.println("Product B Created : "
                    + c.createB(af).getName());
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Problem encountered");
        }
    }

}
