/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.BankOne_Corporation;

/**
 *
 * @author jackh
 */
public abstract class Account {
        private String accountNumber;
        private Double balance;
    public Account(){
        
    }
    public void debit (double amount){
        
    }
    public void credit(double amount){
        
    }
    public abstract int getBalance();
}
