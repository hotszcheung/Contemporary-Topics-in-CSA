/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.KWBank_Corporation;

/**
 *
 * @author jackh
 */
public class InternationalAccount extends ForeignExchangeCalculator{
    private String accountnumber , currency;
    private Double balance;
    
    public InternationalAccount(String accountnumber,String currency,Double balance){
        this.accountnumber = accountnumber;
        this.currency = currency;
        this.balance = balance;
    }
    public void increase (Double amount){
        this.balance = balance + amount;
    } 
    public void decrese(Double amount){
        this.balance = balance - amount;
    }
    public double showbalance() {
        return balance;
    }
   
    public double showbalancelnUSD(int b){
        return HKD2USD(balance);
    }
}
