/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q2_partB;



/**
 *
 * @author a1
 */
public class ClassFractionAdapter extends LongFraction implements Fraction {

    //private LongFraction lf;

    public ClassFractionAdapter(long numerator_, long denominator_) {
      super(numerator_,denominator_);

    }

    public int getNumerator() {
        return (int) super.numerator();

    }

    public int getDenominator() {
         return (int)super.denominator();
        
    }

    public Fraction add(Fraction b) {
        Fraction result = null;
        LongFraction a = new LongFraction(b.getNumerator(), b.getDenominator());
        

        LongFraction lf2 = plus(a);
        result = new ClassFractionAdapter(lf2.numerator_,lf2.denominator_);
        
        return result;

    }

    public Fraction add(int b) {
         Fraction result = null;
       
        
        LongFraction lf2 = plus(b);
        result = new ClassFractionAdapter(lf2.numerator_,lf2.denominator_);;
        return result;

    }

    public Fraction subtract(Fraction b) {
        Fraction result = null;
        LongFraction x = new LongFraction(b.getNumerator(), b.getDenominator());
        
        LongFraction lf2 = minus(x);
        result = new ClassFractionAdapter(lf2.numerator_,lf2.denominator_);;
        
        return result;
    }

    public Fraction subtract(int b) {
       Fraction result = null;
       
        
        LongFraction lf2 = minus(b);
        result = new ClassFractionAdapter(lf2.numerator_,lf2.denominator_);
        
        return result;
    }

    public String toString() {
     return super.toString();
    }

}
