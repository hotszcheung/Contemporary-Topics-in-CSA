/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.SuperBank;
import java.util.*;
/**
 *
 * @author jackh
 */
public class Client {
    private String name,address;
    private Vector<InternationalAccount> accountsAdapter = new Vector<InternationalAccount>();
    
    public Vector<InternationalAccount> getAccountsAdapter() {
        return accountsAdapter;
    }

    public void setAccountsAdapter(Vector<InternationalAccount> accountsAdapter) {
        this.accountsAdapter = accountsAdapter;
    }
    
    public Client(String name,String address){
        this.name = name;
        this.address = address;
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String xname){
        this.name = xname;
    }
    
    public String getAddress(){
        return address;
    }
    
    public void setAddress(String saddress){
        this.address = saddress;
    }
}
