/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.SuperBank;
import java.util.*;

/**
 *
 * @author jackh
 */
public class ClientAdapter extends Client{
    private Customer customer;
    
    public ClientAdapter (Customer customer) {
        this.customer = customer;
    }

    public String getName() {
        return this.customer.getName();
    }

    public void setName(String name) {
        customer.setName(name);
    }

    public String getAddress() {
        return customer.getAddress();
    }

    public void setAddress(String address) {
        customer.setAddress(address);
    }

    public Vector<InternationalAccount> getAccountsAdapter() {
        Vector accountsAdapter = new Vector();
        for(Account accounts : customer.getAllAccounts()) {
            accountsAdapter.addElement(new InternationalAccAdapter(accounts));
        }
        return accountsAdapter;
    }

    public String toString() {
        return " |Client: " + getName() + " |Address: " + getAddress();
    }
}
