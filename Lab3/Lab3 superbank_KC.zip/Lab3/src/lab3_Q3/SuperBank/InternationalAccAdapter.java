/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.SuperBank;

/**
 *
 * @author jackh
 */
public class InternationalAccAdapter {
    private Account account;
    
    
    public  InternationalAccAdapter (Account account) {
        this.account = account;
    }
    
    
    public double getBalance() {
        return account.getBalance();
    }

    public String getAccountNumber() {
        return account.getAccountNumber();
    }

    public void setAccountNumber(String accountNumber) {
        account.setAccountNumber(accountNumber);
    }

    public void decrease(double amount) {
        account.debit(amount);
    }

    public void increase(double amount) {
        account.credit(amount);
    }

    public Client getClient() {
        return new ClientAdapter(account.getCustomer());
    }

    public String toString() {
        return " |AccountNo: " + getAccountNumber() + " |Balance: " + getBalance();
    }
    
}
