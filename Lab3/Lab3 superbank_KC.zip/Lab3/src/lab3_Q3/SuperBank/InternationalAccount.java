/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.SuperBank;
import java.util.*;
/**
 *
 * @author jackh
 */
public class InternationalAccount {
    private String accountnumber;
    private Double balance;
    private String currency;
   

    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }
    public String getAccountnumber() {
        return accountnumber;
    }
    
    
    public void increase(double amount){
         this.balance = balance + amount;
    }
    
    public void decrease(double amount){
        this.balance = balance - amount;
    }
}
