/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.SuperBank;
import java.util.*;
/**
 *
 * @author jackh
 */
public class ForeignExchangeCalculator {
      public double HKD2USD(double amount){
        double a ;
         
        a = amount / 7.78; 
        return a;          
    }
}
