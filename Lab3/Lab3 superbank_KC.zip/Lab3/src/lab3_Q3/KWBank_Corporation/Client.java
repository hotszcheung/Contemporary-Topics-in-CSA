/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.KWBank_Corporation;

/**
 *
 * @author jackh
 */
public class Client {
     public Client(){
      
  }
    public void setname(String xname){
    
    }
    public String getname(){
     return null;    
    }
    public void setaddress (String xaddress){
        
    }
    public String getaddress(){
        return null;
    }
}
