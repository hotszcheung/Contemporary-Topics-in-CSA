/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q3.KWBank_Corporation;

/**
 *
 * @author jackh
 */
public class InternationalAccount {
    private String accountnumber , currency;
    private Double balance;
    
    public void increase (Double amount){
        
    } 
    public void decrese(Double amount){
        
    }
    public double showbalance() {
        return 0;
    }
    public double showbalancelnUSD(){
        return 0;
    }
}
