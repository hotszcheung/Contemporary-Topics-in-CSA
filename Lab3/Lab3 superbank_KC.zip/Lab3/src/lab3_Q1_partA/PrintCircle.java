/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lab3_Q1_partA;

/**
 *
 * @author a1
 */
public class PrintCircle {
    public static void printCircle(NewCircle newCircle) {
	System.out.println(" r = " + newCircle.getRadius( ));
	System.out.println("center = [" + newCircle.getCenter( ).getX() + " , "  
                + newCircle.getCenter( ).getY() + "]");
        }
  public static void main (String args[]){
      OldCircle c1 = new OldCircleImpl(15.0,15.0,25.5);
      NewCircle CircleobjectAdapter = new CircleObjectAdapter(c1);
      
      PrintCircle printCircle = new PrintCircle();
      PrintCircle.printCircle(CircleobjectAdapter);
     
      
  }
}

