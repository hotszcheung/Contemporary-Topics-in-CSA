/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q2_partA;

/**
 *
 * @author a1
 */
public class ObjectFractionAdapter implements Fraction {

    private LongFraction lf;

    public ObjectFractionAdapter(LongFraction lf) {
        this.lf = lf;

    }

    public int getNumerator() {
        return (int) lf.numerator_;

    }

    public int getDenominator() {
         return (int) lf.denominator_;
        
    }

    public Fraction add(Fraction b) {
        Fraction result = null;
        LongFraction a = new LongFraction(b.getNumerator(), b.getDenominator());
        

        LongFraction lf2 = lf.plus(a);
        result = new ObjectFractionAdapter(lf2);
        
        return result;

    }

    public Fraction add(int b) {
         Fraction result = null;
       
        
        LongFraction lf2 = lf.plus(b);
        result = new ObjectFractionAdapter(lf2);
        return result;

    }

    public Fraction subtract(Fraction b) {
        Fraction result = null;
        LongFraction x = new LongFraction(b.getNumerator(), b.getDenominator());
        
        LongFraction lf2 = lf.minus(x);
        result = new ObjectFractionAdapter(lf2);
        
        return result;
    }

    public Fraction subtract(int b) {
       Fraction result = null;
       
        
        LongFraction lf2 = lf.minus(b);
        result = new ObjectFractionAdapter(lf2);
        
        return result;
    }

    public String toString() {
     return lf.toString();
    }

}
