/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_Q1_partB;

import java.awt.Point;

/**
 *
 * @author a1
 */
public class CircleClassAdapter extends OldCircleImpl implements NewCircle {

    
    public Point point;
    
    public CircleClassAdapter(double a, double b, double c) {
      super(a,b,c);
      point = getCenter();
    }

  public double getRadius() {
        double radius = 0;

        
        radius = Math.sqrt(getCoeff()[2]);
        return radius;
    }

    public Point getCenter() {

        point = new Point((int) getCoeff()[0],(int) getCoeff()[1]);

        return point;
    }

}
